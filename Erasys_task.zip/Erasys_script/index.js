const axios = require('axios');
var mysql = require('mysql');

const valid = "valid | '1'";
const invalid = "invalid | '0'" ;

var con = mysql.createConnection({
    host: "remotemysql.com",
    user: "qPUR2OMiH2",
    password: "s3TFR89vQU",
    database: "qPUR2OMiH2"
  });
  
  con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
  });


 
  sql = "SELECT password FROM `passwords`";
  con.query(sql, function (err, result) {
    if (err) throw err;
    else{
    result.forEach(element => {
      axios.post('http://localhost:3000/password', {
        password: element.password
      })
      .then(function () {
        console.log(element.password + " : " + valid)
      })
      .catch(function () {
        console.log(element.password + " : " + invalid);
      });
    });
    }
  });

