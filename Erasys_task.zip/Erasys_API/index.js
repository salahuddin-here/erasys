const express = require('express')
var passwordValidator = require('password-validator');
var schema = new passwordValidator();
const app = express()
const port = 3000

app.use(express.json())

app.post('/password',(req,res)=>{

  schema
  .is().min(5)                                    // Minimum length 8
  .is().max(100)                                  // Maximum length 100
  .has().uppercase()                              // Must have uppercase letters
  .has().lowercase()                              // Must have lowercase letters
  .has().digits(1)                                // Must have at least 2 digits
  .has().not().spaces()                           // Should not have spaces
  .has().symbols()                                // Should have symbols
  .is().not().oneOf(['Passw0rd', 'Password123']); // Blacklist these values
 
  var hasDuplicates = (/(.)\1\1/).test(req.body.password)
 
  if ((hasDuplicates == false) && (schema.validate(req.body.password) == true)){
    res.status(204).send();
    return;
  }
  else{
    list_errors = schema.validate(req.body.password, {list : true})
    const unique = Array.from(new Set(list_errors)) 
    var msg = {error  : unique}
    res.status(400).send(msg);
    return;
  }


});

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`)
});